<template>
  <q-layout view="lHh Lpr lFf">
      <q-header reveal class="bg-blue-grey-10">
      <div class="row no-wrap ">

      <q-toolbar class="col-xs-12 col-sm-3 col-md-3 col-lg-3 col-xl-3 bg-blue-grey-10 ">
         <div class="full-width row text-h6  text-weight-bolder  justify-center items-center content-center">

           <q-btn
         v-if="this.$q.platform.is.mobile"
         class="self-justify-left"
         color="white"
          flat
          dense
          round
          @click="leftDrawerOpen = !leftDrawerOpen"
          icon="menu"
          aria-label="Menu"
        />

          EFFY SETUMENI
          <!-- <img src="~assets/logo.png"  style="height:40px; width:40px"/> -->

         </div>
      </q-toolbar>
      <q-toolbar  v-if="this.$q.platform.is.desktop" class="col-6">

         <q-separator dark vertical inset  />

        <div class="row fit stretch justify-center content-center items-center">

             <q-btn stretch flat label="<developer profile/>" to="/"/>
             <!-- <q-btn stretch flat label="About Us" to="/about" type="a" />
             <q-btn stretch flat label="Initiatives" to="/initiatives" type="a"/>
              <q-btn stretch flat label="Trending" to="/trending" />
             <q-btn stretch flat label="Contact" to="/contact" /> -->
        </div>

         <q-separator dark vertical inset />

      </q-toolbar>
      <q-toolbar  v-if="this.$q.platform.is.desktop" class="col-3 bg-blue-grey-10">
                <q-btn outline icon="mail" color="yellow-9"
                 label="submit enquiry"  />
      </q-toolbar>

      </div>
    </q-header>

    <q-drawer
     :mini="true"
      v-model="leftDrawerOpen"
      show-if-above
      bordered
     dark
    >
      <q-list>
        <q-item-label
          header
        >
          Essential Links
        </q-item-label>

        <EssentialLink
          v-for="link in essentialLinks"
          :key="link.title"
          v-bind="link"
        />
      </q-list>
    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import EssentialLink from 'components/EssentialLink.vue'

const linksList = [
  {
    title: 'Docs',
    caption: 'quasar.dev',
    icon: 'home',
    detail:'home',
    link: '/'
  },
  {
    title: 'Github',
    caption: 'github.com/quasarframework',
    icon: 'code',
    detail:'portfolio',
    link: '/portfolio'
  },
  {
    title: 'Discord Chat Channel',
    caption: 'chat.quasar.dev',
    icon: 'mail',
    detail:'Contact',
    link: '/contact'
  },
  // {
  //   title: 'Forum',
  //   caption: 'forum.quasar.dev',
  //   icon: 'record_voice_over',
  //   link: 'https://forum.quasar.dev'
  // },
  // {
  //   title: 'Twitter',
  //   caption: '@quasarframework',
  //   icon: 'rss_feed',
  //   link: 'https://twitter.quasar.dev'
  // },
  // {
  //   title: 'Facebook',
  //   caption: '@QuasarFramework',
  //   icon: 'public',
  //   link: 'https://facebook.quasar.dev'
  // },
  // {
  //   title: 'Quasar Awesome',
  //   caption: 'Community Quasar projects',
  //   icon: 'favorite',
  //   link: 'https://awesome.quasar.dev'
  // }
];

import { defineComponent, ref } from 'vue'

export default defineComponent({
  name: 'MainLayout',

  components: {
    EssentialLink
  },

  setup () {
    const leftDrawerOpen = ref(false)

    return {
      essentialLinks: linksList,
      leftDrawerOpen,
      toggleLeftDrawer () {
        leftDrawerOpen.value = !leftDrawerOpen.value
      }
    }
  }
})
</script>
