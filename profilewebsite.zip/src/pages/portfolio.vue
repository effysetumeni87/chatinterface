<template>
  <q-page class="flex row flex-center">
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 full-heig
    full-height window-height
     bg-blue-grey-9">

                 <div class="text-blue-grey-10  ">
                   <!-- <loginForm /> -->


                   <div class="text-blue-grey-10 q-ma-md  ">
                     <!-- <loginForm /> -->

                            <q-card dark bordered  flat class="bg-blue-grey-9
                            text-white">
                             <q-card-section class="text-h5
                             text-weight-bolder text-yellow-8
                             ">
                             <q-toolbar class="bg-blue-grey-10
                             justify-center">
                             Projects List
                             </q-toolbar>

                             </q-card-section>
                             <q-separator dark/>
                             <q-card-section class="subtitle1">


                               <q-card-section>
                                <q-separator inset dark />
                                <!-- <q-card dark class="bg-blue-grey-9 text-center
                                 text-weight-bold">
                                  <q-card-section>
                                    Technical Proficiencies
                                  </q-card-section>

                                </q-card> -->
                               </q-card-section>
                               <!-- tanbs -->

                                <div class="q-pa-md">
                                  <div class="q-gutter-y-md"
                                  style="">
                                    <q-card dark>
                                      <q-tabs
                                        v-model="tab" dark
                                        dense
                                        class="text-grey"
                                        active-color="primary"
                                        indicator-color="primary"
                                        align="justify"
                                        narrow-indicator
                                      >
                                        <q-tab name="mails" label="Mails" />
                                        <q-tab name="alarms" label="Alarms" />
                                        <q-tab name="movies" label="Movies" />
                                      </q-tabs>

                                      <q-separator />

                                      <q-tab-panels dark v-model="tab" animated>
                                        <q-tab-panel name="mails">
                                          <div class="text-h6">Mails</div>
                                          Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                        </q-tab-panel>

                                        <q-tab-panel dark name="alarms">
                                          <div class="text-h6">Alarms</div>
                                          Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                        </q-tab-panel>

                                        <q-tab-panel name="movies">
                                          <div class="text-h6">Movies</div>
                                          Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                        </q-tab-panel>
                                      </q-tab-panels>
                                    </q-card>


                                  </div>
                                </div>



                             </q-card-section>

                            </q-card>



                   </div>


                 </div>



        </div>
      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6  full-height    bg-blue-grey-1">
         <q-img transparent src='background.jpg' class="row window-height">
          <div class="absolute-full
          flex flex-center justify-center">
          <q-img    src="portfolio3.png"/>
            <q-card dark flat  class="bg-grey transparent">
              <q-card-section class="row">
                <div class="text-h6 col-12
                 text-weight-bold text-black text-center">
                      <q-card dark size="" bordered
                      style="margin-top:-6rem;"
                      class="bg-blue-grey-10 text-yellow-9 bg-white col-8">


                         <q-card-section>
                          Projects Portfolio
                         </q-card-section>
                      </q-card>

                </div>

              </q-card-section>

              </q-card>
          </div>

         </q-img>
        </div>
  </q-page>
</template>

<script>
import { defineComponent ,ref} from 'vue';

export default defineComponent({
  name: 'portfolio',
  setup () {

    return {
      tab: ref('mails')
    }
  }
})
</script>

<style>

</style>
