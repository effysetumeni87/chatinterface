<template>
  <q-page class="flex row flex-center">
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6
     col-xl-6 full-height window-height
     bg-blue-grey-9">

                 <div class="text-blue-grey-10  ">
                   <!-- <loginForm /> -->


                   <div class="text-blue-grey-10 q-ma-md  ">
                     <!-- <loginForm /> -->

                            <q-card dark bordered  flat class="bg-blue-grey-9
                            text-white">
                             <q-card-section class="text-h5 text-weight-bolder
                              text-yellow-9
                             ">
                             <q-toolbar class="bg-blue-grey-10 justify-center">
                              About
                             </q-toolbar>

                             </q-card-section>
                             <q-separator dark/>
                             <q-card-section class="subtitle1 text-center">
                              I am a fullstack software developer with
                              profiency in various web technologies


                               <q-card-section>
                                <q-separator inset dark />
                                <q-card dark class="bg-blue-grey-9 text-center
                                 text-weight-bold">
                                  <q-card-section>
                                    Technical Proficiencies
                                  </q-card-section>

                                </q-card>

                               </q-card-section>

                               <proficiencies/>
                             </q-card-section>

                            </q-card>



                   </div>


                 </div>



        </div>
      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 full-heig full-height    bg-blue-grey-1">
         <q-img transparent src='background.jpg' class="row window-height">
          <div class="absolute-full
          flex flex-center justify-center">
            <q-card dark flat  class="bg-grey transparent">
              <q-card-section class="row">
                <div class="text-h6 col-12
                 text-weight-bold text-black text-center">
                      <q-card dark size="" bordered
                      class="bg-grey bg-white col-8">
                           <q-btn round style="margin-top:-4rem;">
                             <q-avatar size="100px">
                              <q-img src="effyweb.jpg"/>
                             </q-avatar>
                           </q-btn>
                       <q-card-section class="text-yellow-8 text-weight-bolder">
                        <q-toolbar class="bg-blue-grey-10">
                          Effy Setumeni Developer Profile
                        </q-toolbar>

                       </q-card-section>
                       <q-separator dark inset />
                       <q-card-section class="text-subtitle1" >
                        <div class="full-width row  justify-center items-center content-center">
                          <q-btn
                          round outline
                          size="sm"
                          class=" q-mx-sm  text-white"
                          icon="ion-logo-facebook"
                          color="white"
                          type="a"
                          href="https://www.facebook.com/LabCitizens/"
                          target= "_blank"
                          />

                          <q-separator dark inset vertical />

                          <q-btn
                          round
                          outline
                          size="sm"
                          class="q-mx-sm"
                          icon="ion-logo-linkedin"
                          color="white"
                          type="a"
                          href="https://www.youtube.com/channel/UCtQxN4vCTUC-mkTGLsqvSqg"
                          target= "_blank"
                          />

                          <q-separator dark  inset vertical />

                           <q-btn
                           round
                           outline
                           size="sm"
                           class="q-mx-sm"
                           icon="ion-logo-twitter"
                           color="white"  type="a"
                           href="https://twitter.com/labcitizens"
                           target= "_blank"
                           />
                           <q-separator dark  inset vertical />

                           <q-btn
                           round
                           outline
                           size="sm"
                           class="q-mx-sm"
                           icon="ion-logo-whatsapp"
                           color="white"  type="a"
                           href="https://twitter.com/labcitizens"
                           target= "_blank"
                           />
                       </div>
                       </q-card-section>
                       <q-separator   />
                       <q-card-section class="">
                        <q-btn outline rounded color="blue-grey-10" label="download cv"
                         class="full-width " />
                       </q-card-section>
                      </q-card>
                </div>

              </q-card-section>

              </q-card>
          </div>

         </q-img>
        </div>
  </q-page>
</template>

<script>
import Proficiencies from 'src/components/landingPage/proficiencies.vue';
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'PageIndex',
  components:{
    Proficiencies
},
setup(){

  return{

  }
}
})
</script>
