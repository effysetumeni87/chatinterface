<template>
  <div class="q-pa-md" >
    <q-list bordered>
      <q-expansion-item
        group="somegroup"
        icon="code"
        label="Front-End"
        default-opened
        header-class="text-yellow-9
         text-weight-bolder"
      >
        <q-card dark class=" bg-blue-grey-10">
          <q-card-section style="max-height:110px;"
           class="scroll row justify-between">
           <q-btn class="col-3" label="Javascript"/>
           <q-btn class="col-3" label="html"/>
           <q-btn class="col-3" label="css"/>
           <q-btn class="col-3" label="Vue Js"/>
           <q-btn class="col-3" label="Vuetify"/>
           <q-btn class="col-3" label="Nuxt"/>
           <q-btn class="col-3" label="Quasar"/>
           <q-btn class="col-3" label="Wordpress"/>
          </q-card-section>
        </q-card>
      </q-expansion-item>

      <q-separator />

      <q-expansion-item group="somegroup"
       icon="dns" label="Back-End"
        header-class="text-yellow-9 text-weight-bolder">
        <q-card dark class=" bg-blue-grey-10">
          <q-card-section style="max-height:110px;"
           class="scroll row justify-between">
           <q-btn class="col-3" label="Node Js"/>
           <q-btn class="col-3" label="Mongo DB"/>
           <q-btn class="col-3" label="Firebase"/>
           <q-btn class="col-3" label="PostgreSQL"/>
           <!-- <q-btn class="col-3" label="Vuetify"/>
           <q-btn class="col-3" label="Nuxt"/>
           <q-btn class="col-3" label="Quasar"/> -->
          </q-card-section>
        </q-card>
      </q-expansion-item>

      <q-separator />

      <q-expansion-item group="somegroup"
       icon="cloud_sync" label="Cloud Services"
       header-class="text-yellow-9 text-weight-bolder">
       <q-card dark class=" bg-blue-grey-10">
        <q-card-section style="max-height:110px;"
         class="scroll row justify-between">
         <q-btn class="col-3" label="GCP"/>
         <q-btn class="col-3" label="Mongo Atlass"/>
         <q-btn class="col-3" label="Vercel"/>
         <q-btn class="col-3" label="Supabase"/>
         <!-- <q-btn class="col-3" label="Vuetify"/>
         <q-btn class="col-3" label="Nuxt"/>
         <q-btn class="col-3" label="Quasar"/> -->
        </q-card-section>
      </q-card>
      </q-expansion-item>

      <q-separator />

      <q-expansion-item
        group="somegroup"
        icon="devices_other"
        label="A.I and Mobile Apps"
        header-class="text-weight-bolder  text-yellow-9"
        expand-icon-class="text-white"
      >
      <q-card dark class=" bg-blue-grey-10">
        <q-card-section style="max-height:110px;"
         class="scroll row justify-between">
         <q-btn class="col-3" label="Langchain"/>
         <q-btn class="col-3" label="Open Ai"/>
         <q-btn class="col-3" label="capacitor"/>
         <q-btn class="col-3" label="cordova"/>
         <!-- <q-btn class="col-3" label="Vuetify"/>
         <q-btn class="col-3" label="Nuxt"/>
         <q-btn class="col-3" label="Quasar"/> -->
        </q-card-section>
      </q-card>
      </q-expansion-item>
      <q-separator />

    </q-list>
  </div>

</template>
<script>
import { defineComponent } from 'vue'

export default defineComponent({
    setup() {

    },
})
</script>
