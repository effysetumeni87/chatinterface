<template>
  <q-item
    clickable

    :to="link"

  >
    <q-item-section
      v-if="icon"
      avatar
    >

      <q-btn size="xs" no-caps stack  :icon="icon" >
        <span class="">{{detail}}</span>
        </q-btn>

    </q-item-section>
       <!-- <span class="text-caption"></span> -->
    <q-item-section>
      <q-item-label>{{ title }}</q-item-label>
      <q-item-label caption>
        {{ caption }}
      </q-item-label>
    </q-item-section>
  </q-item>
</template>

<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'EssentialLink',
  props: {
    title: {
      type: String,
      required: true
    },

    caption: {
      type: String,
      default: ''
    },

    link: {
      type: String,
      default: '#'
    },

    icon: {
      type: String,
      default: ''
    },
    detail: {
      type: String,
      default: 'hg'
    }
  }
})
</script>
